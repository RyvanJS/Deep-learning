The MNIST dataset. See http://yann.lecun.com/exdb/mnist/. 
